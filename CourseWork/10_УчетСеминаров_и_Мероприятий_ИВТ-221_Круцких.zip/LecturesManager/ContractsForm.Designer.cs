﻿namespace LecturesManager
{
    partial class ContractsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewContract = new DataGridView();
            ClientID = new Label();
            NumberContract = new Label();
            DateConclusion = new Label();
            Summ = new Label();
            comboBoxClientID = new ComboBox();
            textBoxNumberContract = new TextBox();
            dateTimePickerData = new DateTimePicker();
            textBoxSumm = new TextBox();
            AddContract = new Button();
            UpdateContract = new Button();
            DeleteContract = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewContract).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewContract
            // 
            dataGridViewContract.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewContract.Location = new Point(287, 12);
            dataGridViewContract.Name = "dataGridViewContract";
            dataGridViewContract.RowTemplate.Height = 25;
            dataGridViewContract.Size = new Size(501, 426);
            dataGridViewContract.TabIndex = 0;
            // 
            // ClientID
            // 
            ClientID.AutoSize = true;
            ClientID.Location = new Point(65, 70);
            ClientID.Name = "ClientID";
            ClientID.Size = new Size(60, 15);
            ClientID.TabIndex = 2;
            ClientID.Text = "Клиент ID";
            // 
            // NumberContract
            // 
            NumberContract.AutoSize = true;
            NumberContract.Location = new Point(26, 107);
            NumberContract.Name = "NumberContract";
            NumberContract.Size = new Size(99, 15);
            NumberContract.TabIndex = 3;
            NumberContract.Text = "Номер договора";
            // 
            // DateConclusion
            // 
            DateConclusion.AutoSize = true;
            DateConclusion.Location = new Point(23, 137);
            DateConclusion.Name = "DateConclusion";
            DateConclusion.Size = new Size(102, 15);
            DateConclusion.TabIndex = 4;
            DateConclusion.Text = "Дата заключения";
            // 
            // Summ
            // 
            Summ.AutoSize = true;
            Summ.Location = new Point(80, 171);
            Summ.Name = "Summ";
            Summ.Size = new Size(45, 15);
            Summ.TabIndex = 5;
            Summ.Text = "Сумма";
            // 
            // comboBoxClientID
            // 
            comboBoxClientID.FormattingEnabled = true;
            comboBoxClientID.Location = new Point(131, 65);
            comboBoxClientID.Name = "comboBoxClientID";
            comboBoxClientID.Size = new Size(150, 23);
            comboBoxClientID.TabIndex = 7;
            // 
            // textBoxNumberContract
            // 
            textBoxNumberContract.Location = new Point(131, 104);
            textBoxNumberContract.Name = "textBoxNumberContract";
            textBoxNumberContract.Size = new Size(150, 23);
            textBoxNumberContract.TabIndex = 8;
            // 
            // dateTimePickerData
            // 
            dateTimePickerData.Location = new Point(131, 133);
            dateTimePickerData.Name = "dateTimePickerData";
            dateTimePickerData.Size = new Size(150, 23);
            dateTimePickerData.TabIndex = 9;
            // 
            // textBoxSumm
            // 
            textBoxSumm.Location = new Point(131, 168);
            textBoxSumm.Name = "textBoxSumm";
            textBoxSumm.Size = new Size(150, 23);
            textBoxSumm.TabIndex = 10;
            // 
            // AddContract
            // 
            AddContract.Location = new Point(80, 237);
            AddContract.Name = "AddContract";
            AddContract.Size = new Size(84, 27);
            AddContract.TabIndex = 11;
            AddContract.Text = "Добавить";
            AddContract.UseVisualStyleBackColor = true;
            AddContract.Click += AddContract_Click;
            // 
            // UpdateContract
            // 
            UpdateContract.Location = new Point(80, 270);
            UpdateContract.Name = "UpdateContract";
            UpdateContract.Size = new Size(84, 23);
            UpdateContract.TabIndex = 12;
            UpdateContract.Text = "Обновить";
            UpdateContract.UseVisualStyleBackColor = true;
            UpdateContract.Click += UpdateContract_Click;
            // 
            // DeleteContract
            // 
            DeleteContract.Location = new Point(80, 299);
            DeleteContract.Name = "DeleteContract";
            DeleteContract.Size = new Size(84, 23);
            DeleteContract.TabIndex = 13;
            DeleteContract.Text = "Удалить";
            DeleteContract.UseVisualStyleBackColor = true;
            DeleteContract.Click += DeleteContract_Click;
            // 
            // ContractsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteContract);
            Controls.Add(UpdateContract);
            Controls.Add(AddContract);
            Controls.Add(textBoxSumm);
            Controls.Add(dateTimePickerData);
            Controls.Add(textBoxNumberContract);
            Controls.Add(comboBoxClientID);
            Controls.Add(Summ);
            Controls.Add(DateConclusion);
            Controls.Add(NumberContract);
            Controls.Add(ClientID);
            Controls.Add(dataGridViewContract);
            Name = "ContractsForm";
            Text = "Договоры";
            Load += ContractsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewContract).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewContract;
        private Label ClientID;
        private Label NumberContract;
        private Label DateConclusion;
        private Label Summ;
        private ComboBox comboBoxClientID;
        private TextBox textBoxNumberContract;
        private DateTimePicker dateTimePickerData;
        private TextBox textBoxSumm;
        private Button AddContract;
        private Button UpdateContract;
        private Button DeleteContract;
    }
}