﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LecturesManager
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
            SetAboutText();
        }

        private void SetAboutText()
        {
            // Настройка текста элемента Label
            aboutlabel.Text = "Учет семинаров и мероприятий \n" +
                               "Разработчик: Круцких Никита Дмитриевич\n" +
                               "Группа: ИВТ-221";
        }

        private void aboutlabel_Click(object sender, EventArgs e)
        {

        }
    }
}
