﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LecturesManager
{
    public partial class VisitsForm : Form
    {
        private string connectionString;
        private SqlDataAdapter adapter;
        private DataTable dataTable;


        public VisitsForm(string connectionString)
        {
            InitializeComponent();
            this.connectionString = connectionString;
            fetchData();
            fetchVisitsEvents();
            fetchVisitsClients();
        }


        private void fetchData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Посещение_ID, Мероприятие_ID, Клиент_ID, Дата_посещения FROM Посещения";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ApplyCellStyle(dataGridViewVisits);
                    dataGridViewVisits.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о договорах: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fetchVisitsEvents()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Мероприятие_ID, Название_мероприятия FROM Мероприятия";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    foreach (DataRow row in dataTable.Rows)
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Text = (string)row["Название_мероприятия"];
                        item.Id = (int)row["Мероприятие_ID"];

                        comboBoxEventsID.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о мероприятиях: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fetchVisitsClients()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Клиент_ID, Контактное_лицо FROM Клиенты";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    foreach (DataRow row in dataTable.Rows)
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Text = (string)row["Контактное_лицо"];
                        item.Id = (int)row["Клиент_ID"];

                        comboBoxClientID.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о клиентах: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void AddVisits_Click(object sender, EventArgs e)
        {
            int EventID = ((ComboboxItem)comboBoxEventsID.SelectedItem).Id;
            int clientID = ((ComboboxItem)comboBoxClientID.SelectedItem).Id;
            DateTime DateVisit = dateTimePickerVisits.Value;

            if ((comboBoxEventsID.SelectedIndex == -1) || (comboBoxClientID.SelectedIndex == -1) || (dateTimePickerVisits.Value == DateTime.Now))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Посещения (Мероприятие_ID, Клиент_ID, Дата_посещения) VALUES (@EventID, @clientID, @DateVisit)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@EventID", EventID);
                command.Parameters.AddWithValue("@clientID", clientID);
                command.Parameters.AddWithValue("@DateVisit", DateVisit);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    fetchData();
                    ClearInputFields();
                    MessageBox.Show("Посещение успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении посещения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UpdateVisits_Click(object sender, EventArgs e)
        {
            if (dataGridViewVisits.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите посещение для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewVisits.SelectedRows[0].Index;
            int VisitId = Convert.ToInt32(dataGridViewVisits.Rows[selectedIndex].Cells["Посещение_ID"].Value);

            int EventID = ((ComboboxItem)comboBoxEventsID.SelectedItem).Id;
            int clientID = ((ComboboxItem)comboBoxClientID.SelectedItem).Id;
            DateTime DateVisit = dateTimePickerVisits.Value;

            if ((comboBoxEventsID.SelectedIndex == -1) || (comboBoxClientID.SelectedIndex == -1) || (dateTimePickerVisits.Value == DateTime.Now))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Посещения SET Мероприятие_ID = @EventID, Клиент_ID = @clientID, Дата_посещения = @DateVisit WHERE Посещение_ID = @VisitId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@VisitId", VisitId);
                command.Parameters.AddWithValue("@EventID", EventID);
                command.Parameters.AddWithValue("@clientID", clientID);
                command.Parameters.AddWithValue("@DateVisit", DateVisit);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        fetchData();
                        MessageBox.Show("Посещение успешно изменено.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось изменить посещение.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при изменении посещения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DeleteVisits_Click(object sender, EventArgs e)
        {
            if (dataGridViewVisits.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите посещение для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewVisits.SelectedRows[0].Index;
            int VisitId = Convert.ToInt32(dataGridViewVisits.Rows[selectedIndex].Cells["Посещение_ID"].Value);

            if (MessageBox.Show("Вы уверены, что хотите посещени с кодом " + VisitId + "?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Посещения WHERE Посещение_ID = @VisitId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@VisitId", VisitId);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        MessageBox.Show("Посещение успешно удален.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении посещния: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ClearInputFields()
        {
            comboBoxEventsID.SelectedIndex = -1;
            comboBoxClientID.SelectedIndex = -1;
            dateTimePickerVisits.Value = DateTime.Now;
        }


        static public void ApplyCellStyle(DataGridView dataGridView)
        {
            dataGridView.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
            dataGridView.BorderStyle = BorderStyle.FixedSingle;
        }

        private void VisitsForm_Load(object sender, EventArgs e)
        {

        }

        
    }
}
