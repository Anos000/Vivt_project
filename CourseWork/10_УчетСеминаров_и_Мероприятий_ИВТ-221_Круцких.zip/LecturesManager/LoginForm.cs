﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LecturesManager
{
    public partial class LoginForm : Form
    {
        // Строка подключения к базе данных
        private string connectionString = @"Data Source=NIKITA-PC;Initial Catalog=Учет_мероприятий_и_семинаров;Integrated Security=True";

        public LoginForm()
        {
            InitializeComponent();

            loginButton.Click += new System.EventHandler(LoginButton_Click);
            // Привязка обработчика события к кнопке ExitButton
            this.Outbutton.Click += new System.EventHandler(this.Outbutton_Click);
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if ((this.userName.Text == "") || (this.password.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string username = this.userName.Text;
            string password = this.password.Text;

            // Запрос к базе данных для проверки учетных данных и роли пользователя
            string query = "SELECT Роль FROM Пользователи WHERE Логин = @Username AND Пароль = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);

                try
                {
                    connection.Open();
                    string role = (string)command.ExecuteScalar();

                    if (!string.IsNullOrEmpty(role))
                    {
                        if (role.ToLower() == "администратор")
                        {
                            AdminForm form = new AdminForm(connectionString);
                            form.Show();

                            this.Hide();
                        }
                        else
                        {
                            UserRoleForm form = new UserRoleForm(connectionString);
                            form.Show();

                            this.Hide();
                        }
                    }
                    else
                    {
                        // Ошибка аутентификации
                        MessageBox.Show("Неверное имя пользователя или пароль.", "Ошибка входа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void loginButton_Click_1(object sender, EventArgs e)
        {

        }

        private void Outbutton_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Закрытие приложения
        }

        private void buttonProgram_Click(object sender, EventArgs e)
        {
            // Создаем и отображаем форму "О программе"
            AboutForm aboutForm = new AboutForm();
            aboutForm.Show();
        }
    }
}
