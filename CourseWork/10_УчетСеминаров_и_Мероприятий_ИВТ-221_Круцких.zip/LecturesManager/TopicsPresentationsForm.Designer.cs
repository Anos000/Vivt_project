﻿namespace LecturesManager
{
    partial class TopicsPresentationsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewTopics = new DataGridView();
            EventsId = new Label();
            ParticipantID = new Label();
            TopicsPresen = new Label();
            comboBoxEventsID = new ComboBox();
            comboBoxParticipantClient = new ComboBox();
            textBoxTpicsPresen = new TextBox();
            AddTopics = new Button();
            UpdateTopics = new Button();
            DeleteTopics = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTopics).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewTopics
            // 
            dataGridViewTopics.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTopics.Location = new Point(302, 12);
            dataGridViewTopics.Name = "dataGridViewTopics";
            dataGridViewTopics.RowTemplate.Height = 25;
            dataGridViewTopics.Size = new Size(486, 426);
            dataGridViewTopics.TabIndex = 0;
            // 
            // EventsId
            // 
            EventsId.AutoSize = true;
            EventsId.Location = new Point(24, 67);
            EventsId.Name = "EventsId";
            EventsId.Size = new Size(97, 15);
            EventsId.TabIndex = 2;
            EventsId.Text = "Мероприятие ID";
            // 
            // ParticipantID
            // 
            ParticipantID.AutoSize = true;
            ParticipantID.Location = new Point(49, 104);
            ParticipantID.Name = "ParticipantID";
            ParticipantID.Size = new Size(72, 15);
            ParticipantID.TabIndex = 3;
            ParticipantID.Text = "Участник ID";
            // 
            // TopicsPresen
            // 
            TopicsPresen.AutoSize = true;
            TopicsPresen.Location = new Point(12, 138);
            TopicsPresen.Name = "TopicsPresen";
            TopicsPresen.Size = new Size(109, 15);
            TopicsPresen.TabIndex = 4;
            TopicsPresen.Text = "Тема выступления";
            // 
            // comboBoxEventsID
            // 
            comboBoxEventsID.FormattingEnabled = true;
            comboBoxEventsID.Location = new Point(143, 64);
            comboBoxEventsID.Name = "comboBoxEventsID";
            comboBoxEventsID.Size = new Size(132, 23);
            comboBoxEventsID.TabIndex = 6;
            // 
            // comboBoxParticipantClient
            // 
            comboBoxParticipantClient.FormattingEnabled = true;
            comboBoxParticipantClient.Location = new Point(143, 101);
            comboBoxParticipantClient.Name = "comboBoxParticipantClient";
            comboBoxParticipantClient.Size = new Size(132, 23);
            comboBoxParticipantClient.TabIndex = 7;
            // 
            // textBoxTpicsPresen
            // 
            textBoxTpicsPresen.Location = new Point(143, 135);
            textBoxTpicsPresen.Name = "textBoxTpicsPresen";
            textBoxTpicsPresen.Size = new Size(132, 23);
            textBoxTpicsPresen.TabIndex = 8;
            // 
            // AddTopics
            // 
            AddTopics.Location = new Point(99, 208);
            AddTopics.Name = "AddTopics";
            AddTopics.Size = new Size(92, 23);
            AddTopics.TabIndex = 9;
            AddTopics.Text = "Добавить";
            AddTopics.UseVisualStyleBackColor = true;
            AddTopics.Click += AddTopics_Click;
            // 
            // UpdateTopics
            // 
            UpdateTopics.Location = new Point(99, 237);
            UpdateTopics.Name = "UpdateTopics";
            UpdateTopics.Size = new Size(92, 23);
            UpdateTopics.TabIndex = 10;
            UpdateTopics.Text = "Обновить";
            UpdateTopics.UseVisualStyleBackColor = true;
            UpdateTopics.Click += UpdateTopics_Click;
            // 
            // DeleteTopics
            // 
            DeleteTopics.Location = new Point(99, 266);
            DeleteTopics.Name = "DeleteTopics";
            DeleteTopics.Size = new Size(92, 23);
            DeleteTopics.TabIndex = 11;
            DeleteTopics.Text = "Удалить";
            DeleteTopics.UseVisualStyleBackColor = true;
            DeleteTopics.Click += DeleteTopics_Click;
            // 
            // TopicsPresentationsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteTopics);
            Controls.Add(UpdateTopics);
            Controls.Add(AddTopics);
            Controls.Add(textBoxTpicsPresen);
            Controls.Add(comboBoxParticipantClient);
            Controls.Add(comboBoxEventsID);
            Controls.Add(TopicsPresen);
            Controls.Add(ParticipantID);
            Controls.Add(EventsId);
            Controls.Add(dataGridViewTopics);
            Name = "TopicsPresentationsForm";
            Text = "Темы выступлений";
            Load += TopicsPresentationsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewTopics).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewTopics;
        private Label EventsId;
        private Label ParticipantID;
        private Label TopicsPresen;
        private ComboBox comboBoxEventsID;
        private ComboBox comboBoxParticipantClient;
        private TextBox textBoxTpicsPresen;
        private Button AddTopics;
        private Button UpdateTopics;
        private Button DeleteTopics;
    }
}