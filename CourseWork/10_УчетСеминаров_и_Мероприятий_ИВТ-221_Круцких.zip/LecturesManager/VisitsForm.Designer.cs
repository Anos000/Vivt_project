﻿namespace LecturesManager
{
    partial class VisitsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewVisits = new DataGridView();
            Event_ID = new Label();
            ClientID = new Label();
            DataStart = new Label();
            comboBoxEventsID = new ComboBox();
            comboBoxClientID = new ComboBox();
            dateTimePickerVisits = new DateTimePicker();
            AddVisits = new Button();
            UpdateVisits = new Button();
            DeleteVisits = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewVisits).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewVisits
            // 
            dataGridViewVisits.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewVisits.Location = new Point(305, 12);
            dataGridViewVisits.Name = "dataGridViewVisits";
            dataGridViewVisits.RowTemplate.Height = 25;
            dataGridViewVisits.Size = new Size(483, 426);
            dataGridViewVisits.TabIndex = 0;
            // 
            // Event_ID
            // 
            Event_ID.AutoSize = true;
            Event_ID.Location = new Point(14, 71);
            Event_ID.Name = "Event_ID";
            Event_ID.Size = new Size(97, 15);
            Event_ID.TabIndex = 2;
            Event_ID.Text = "Мероприятие ID";
            // 
            // ClientID
            // 
            ClientID.AutoSize = true;
            ClientID.Location = new Point(51, 105);
            ClientID.Name = "ClientID";
            ClientID.Size = new Size(60, 15);
            ClientID.TabIndex = 3;
            ClientID.Text = "Клиент ID";
            // 
            // DataStart
            // 
            DataStart.AutoSize = true;
            DataStart.Location = new Point(12, 143);
            DataStart.Name = "DataStart";
            DataStart.Size = new Size(98, 15);
            DataStart.TabIndex = 4;
            DataStart.Text = "Дата посещения";
            // 
            // comboBoxEventsID
            // 
            comboBoxEventsID.FormattingEnabled = true;
            comboBoxEventsID.Location = new Point(140, 68);
            comboBoxEventsID.Name = "comboBoxEventsID";
            comboBoxEventsID.Size = new Size(146, 23);
            comboBoxEventsID.TabIndex = 6;
            // 
            // comboBoxClientID
            // 
            comboBoxClientID.FormattingEnabled = true;
            comboBoxClientID.Location = new Point(140, 102);
            comboBoxClientID.Name = "comboBoxClientID";
            comboBoxClientID.Size = new Size(146, 23);
            comboBoxClientID.TabIndex = 7;
            // 
            // dateTimePickerVisits
            // 
            dateTimePickerVisits.Location = new Point(140, 137);
            dateTimePickerVisits.Name = "dateTimePickerVisits";
            dateTimePickerVisits.Size = new Size(146, 23);
            dateTimePickerVisits.TabIndex = 8;
            // 
            // AddVisits
            // 
            AddVisits.Location = new Point(105, 217);
            AddVisits.Name = "AddVisits";
            AddVisits.Size = new Size(87, 23);
            AddVisits.TabIndex = 9;
            AddVisits.Text = "Добавить";
            AddVisits.UseVisualStyleBackColor = true;
            AddVisits.Click += AddVisits_Click;
            // 
            // UpdateVisits
            // 
            UpdateVisits.Location = new Point(105, 246);
            UpdateVisits.Name = "UpdateVisits";
            UpdateVisits.Size = new Size(87, 23);
            UpdateVisits.TabIndex = 10;
            UpdateVisits.Text = "Обновить";
            UpdateVisits.UseVisualStyleBackColor = true;
            UpdateVisits.Click += UpdateVisits_Click;
            // 
            // DeleteVisits
            // 
            DeleteVisits.Location = new Point(105, 275);
            DeleteVisits.Name = "DeleteVisits";
            DeleteVisits.Size = new Size(87, 23);
            DeleteVisits.TabIndex = 11;
            DeleteVisits.Text = "Удалить";
            DeleteVisits.UseVisualStyleBackColor = true;
            DeleteVisits.Click += DeleteVisits_Click;
            // 
            // VisitsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteVisits);
            Controls.Add(UpdateVisits);
            Controls.Add(AddVisits);
            Controls.Add(dateTimePickerVisits);
            Controls.Add(comboBoxClientID);
            Controls.Add(comboBoxEventsID);
            Controls.Add(DataStart);
            Controls.Add(ClientID);
            Controls.Add(Event_ID);
            Controls.Add(dataGridViewVisits);
            Name = "VisitsForm";
            Text = "Посещения";
            Load += VisitsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewVisits).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewVisits;
        private Label Event_ID;
        private Label ClientID;
        private Label DataStart;
        private ComboBox comboBoxEventsID;
        private ComboBox comboBoxClientID;
        private DateTimePicker dateTimePickerVisits;
        private Button AddVisits;
        private Button UpdateVisits;
        private Button DeleteVisits;
    }
}