﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LecturesManager
{
    public partial class TopicsPresentationsForm : Form
    {
        private string connectionString;
        private SqlDataAdapter adapter;
        private DataTable dataTable;


        public TopicsPresentationsForm(string connectionString)
        {
            InitializeComponent();
            this.connectionString = connectionString;
            fetchData();
            fetchPresentationEvents();
            fetchPresentationClients();
        }

        private void fetchData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Тема_ID, Мероприятие_ID, Участник_ID, Тема_выступления FROM Темы_выступлений";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ApplyCellStyle(dataGridViewTopics);
                    dataGridViewTopics.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о темах выступлений: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fetchPresentationEvents()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Мероприятие_ID, Название_мероприятия FROM Мероприятия";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    foreach (DataRow row in dataTable.Rows)
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Text = (string)row["Название_мероприятия"];
                        item.Id = (int)row["Мероприятие_ID"];

                        comboBoxEventsID.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о мероприятиях: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fetchPresentationClients()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Участник_ID, Имя FROM Участники";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    foreach (DataRow row in dataTable.Rows)
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Text = (string)row["Имя"];
                        item.Id = (int)row["Участник_ID"];

                        comboBoxParticipantClient.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о участниках: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddTopics_Click(object sender, EventArgs e)
        {
            int EventID = ((ComboboxItem)comboBoxEventsID.SelectedItem).Id;
            int clientID = ((ComboboxItem)comboBoxParticipantClient.SelectedItem).Id;
            string topics = textBoxTpicsPresen.Text;

            if ((comboBoxEventsID.SelectedIndex == -1) || (comboBoxParticipantClient.SelectedIndex == -1) || (textBoxTpicsPresen.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Темы_выступлений (Мероприятие_ID, Участник_ID, Тема_выступления) VALUES (@EventID, @clientID, @topics)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@EventID", EventID);
                command.Parameters.AddWithValue("@clientID", clientID);
                command.Parameters.AddWithValue("@topics", topics);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    fetchData();
                    ClearInputFields();
                    MessageBox.Show("Посещение успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении посещения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UpdateTopics_Click(object sender, EventArgs e)
        {
            if (dataGridViewTopics.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите посещение для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewTopics.SelectedRows[0].Index;
            int TopicsId = Convert.ToInt32(dataGridViewTopics.Rows[selectedIndex].Cells["Тема_ID"].Value);

            int EventID = ((ComboboxItem)comboBoxEventsID.SelectedItem).Id;
            int clientID = ((ComboboxItem)comboBoxParticipantClient.SelectedItem).Id;
            string topics = textBoxTpicsPresen.Text;

            if ((comboBoxEventsID.SelectedIndex == -1) || (comboBoxParticipantClient.SelectedIndex == -1) || (textBoxTpicsPresen.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Темы_выступлений SET Мероприятие_ID = @EventID, Участник_ID = @clientID, Тема_выступления = @topics WHERE Тема_ID = @TopicsId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TopicsId", TopicsId);
                command.Parameters.AddWithValue("@EventID", EventID);
                command.Parameters.AddWithValue("@clientID", clientID);
                command.Parameters.AddWithValue("@topics", topics);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        fetchData();
                        MessageBox.Show("Тема успешно изменена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось изменить тему.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при изменении темы: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DeleteTopics_Click(object sender, EventArgs e)
        {
            if (dataGridViewTopics.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите тему для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewTopics.SelectedRows[0].Index;
            int TopicsId = Convert.ToInt32(dataGridViewTopics.Rows[selectedIndex].Cells["Тема_ID"].Value);

            if (MessageBox.Show("Вы уверены, что хотите тему с кодом " + TopicsId + "?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Темы_выступлений WHERE Тема_ID = @TopicsId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@TopicsId", TopicsId);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        MessageBox.Show("Тема успешно удален.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении темы: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ClearInputFields()
        {
            comboBoxEventsID.SelectedIndex = -1;
            comboBoxParticipantClient.SelectedIndex = -1;
            textBoxTpicsPresen.Text = "";
        }

        static public void ApplyCellStyle(DataGridView dataGridView)
        {
            dataGridView.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
            dataGridView.BorderStyle = BorderStyle.FixedSingle;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TopicsPresentationsForm_Load(object sender, EventArgs e)
        {

        }

        
    }
}
