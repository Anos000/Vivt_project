﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LecturesManager
{
    public partial class ContractsForm : Form
    {
        private string connectionString;
        private SqlDataAdapter adapter;
        private DataTable dataTable;


        public ContractsForm(string connectionString)
        {
            InitializeComponent();
            this.connectionString = connectionString;
            fetchData();
            fetchClients();
        }

        private void fetchData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Договор_ID, Клиент_ID, Номер_Договора, Дата_заключения, Сумма FROM Договоры";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ApplyCellStyle(dataGridViewContract);
                    dataGridViewContract.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о договорах: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fetchClients()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Клиент_ID, Название_организации FROM Клиенты";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    foreach (DataRow row in dataTable.Rows)
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Text = (string)row["Название_организации"];
                        item.Id = (int)row["Клиент_ID"];

                        comboBoxClientID.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о договорах: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static public void ApplyCellStyle(DataGridView dataGridView)
        {
            dataGridView.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
            dataGridView.BorderStyle = BorderStyle.FixedSingle;
        }

        private void AddContract_Click(object sender, EventArgs e)
        {
            if ((comboBoxClientID.SelectedIndex == -1) || (textBoxNumberContract.Text == "") || (dateTimePickerData.Value == DateTime.Now) || (textBoxSumm.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }
            int clientId = ((ComboboxItem)comboBoxClientID.SelectedItem).Id;
            string orderNumber = textBoxNumberContract.Text;
            DateTime orderDate = dateTimePickerData.Value;
            int orderAmont = int.Parse(textBoxSumm.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Договоры (Клиент_ID, Номер_Договора, Дата_заключения, Сумма) VALUES (@ClientId, @OrderNumber, @OrderDate, @Amount)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ClientId", clientId);
                command.Parameters.AddWithValue("@OrderNumber", orderNumber);
                command.Parameters.AddWithValue("@OrderDate", orderDate);
                command.Parameters.AddWithValue("@Amount", orderAmont);

                
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    fetchData();
                    ClearInputFields();
                    MessageBox.Show("Договор успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении договора: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
                

            }
        }

        private void UpdateContract_Click(object sender, EventArgs e)
        {
            if (dataGridViewContract.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите договор для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            if ((comboBoxClientID.SelectedIndex == -1) || (textBoxNumberContract.Text == "") || (dateTimePickerData.Value == DateTime.Now) || (textBoxSumm.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            int selectedIndex = dataGridViewContract.SelectedRows[0].Index;
            int orderId = Convert.ToInt32(dataGridViewContract.Rows[selectedIndex].Cells["Договор_ID"].Value);

            int clientId = ((ComboboxItem)comboBoxClientID.SelectedItem).Id;
            string orderNumber = textBoxNumberContract.Text;
            DateTime orderDate = dateTimePickerData.Value;
            int orderAmont = int.Parse(textBoxSumm.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Договоры SET Клиент_ID = @ClientId, Номер_Договора = @OrderNumber, Дата_заключения = @OrderDate, Сумма = @Amount WHERE Договор_ID = @OrderId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OrderId", orderId);
                command.Parameters.AddWithValue("@ClientId", clientId);
                command.Parameters.AddWithValue("@OrderNumber", orderNumber);
                command.Parameters.AddWithValue("@OrderDate", orderDate);
                command.Parameters.AddWithValue("@Amount", orderAmont);

                if ((comboBoxClientID.SelectedIndex != -1) && (textBoxNumberContract.Text != "") && (dateTimePickerData.Value != DateTime.Now) && (textBoxSumm.Text != ""))
                {
                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            fetchData();
                            MessageBox.Show("Договор успешно изменен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Не удалось изменить договор.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при изменении договор: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }


        }

        private void DeleteContract_Click(object sender, EventArgs e)
        {
            if (dataGridViewContract.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите договор для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewContract.SelectedRows[0].Index;
            int orderId = Convert.ToInt32(dataGridViewContract.Rows[selectedIndex].Cells["Договор_ID"].Value);

            if (MessageBox.Show("Вы уверены, что хотите удалить договор с кодом " + orderId + "?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Договоры WHERE Договор_ID = @OrderId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@OrderId", orderId);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        MessageBox.Show("Договор успешно удален.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении договора: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ClearInputFields()
        {
            comboBoxClientID.SelectedIndex = -1;
            textBoxNumberContract.Text = "";
            dateTimePickerData.Value = DateTime.Now;
            textBoxSumm.Text = "";
        }

        private void ContractsForm_Load(object sender, EventArgs e)
        {

        }
    }

    public class ComboboxItem
    {
        public string Text { get; set; }
        public int Id { get; set; }

        public override string ToString()
        {
            return Text;
        }
    }
}

