﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LecturesManager
{
    public partial class CustomersForm : Form
    {
        private string connectionString;
        private SqlDataAdapter adapter;
        private DataTable dataTable;

        public CustomersForm(string connectionString)
        {
            InitializeComponent();
            this.connectionString = connectionString;
            fetchData();

        }

        private void fetchData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Клиент_ID, Название_организации, Адрес, Контактное_лицо, Телефон FROM Клиенты";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ApplyCellStyle(dataGridViewCustomers);
                    dataGridViewCustomers.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о клентах: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static public void ApplyCellStyle(DataGridView dataGridView)
        {
            dataGridView.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
            dataGridView.BorderStyle = BorderStyle.FixedSingle;
        }

        private void AddCustomers_Click(object sender, EventArgs e)
        {
            if ((textBoxNameOrg.Text == "") || (textBoxAdress.Text == "") || (textBoxContactName.Text == "") || (textBoxPhone.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
 
                return;
            }

            string NameOrg = textBoxNameOrg.Text;
            string adres = textBoxAdress.Text;
            string contactName = textBoxContactName.Text;
            int phone = int.Parse(textBoxPhone.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Клиенты (Название_организации, Адрес, Контактное_лицо, Телефон) VALUES (@NameOrg, @adres, @contactName, @phone)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@NameOrg", NameOrg);
                command.Parameters.AddWithValue("@adres", adres);
                command.Parameters.AddWithValue("@contactName", contactName);
                command.Parameters.AddWithValue("@phone", phone);
                
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    fetchData();
                    ClearInputFields();
                    MessageBox.Show("Клиент успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении клиента: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
                

            }
        }

        private void UpdateCustomers_Click(object sender, EventArgs e)
        {
            if (dataGridViewCustomers.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите клиента для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            if ((textBoxNameOrg.Text == "") || (textBoxAdress.Text == "") || (textBoxContactName.Text == "") || (textBoxPhone.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            int selectedIndex = dataGridViewCustomers.SelectedRows[0].Index;
            int ClientId = Convert.ToInt32(dataGridViewCustomers.Rows[selectedIndex].Cells["Клиент_ID"].Value);

            string NameOrg = textBoxNameOrg.Text;
            string adres = textBoxAdress.Text;
            string contactName = textBoxContactName.Text;
            int phone = int.Parse(textBoxPhone.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Клиенты SET  Название_организации = @NameOrg, Адрес = @adres, Контактное_лицо = @contactName, Телефон = @phone  WHERE Клиент_ID = @ClientId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ClientId", ClientId);
                command.Parameters.AddWithValue("@NameOrg", NameOrg);
                command.Parameters.AddWithValue("@adres", adres);
                command.Parameters.AddWithValue("@contactName", contactName);
                command.Parameters.AddWithValue("@phone", phone);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        fetchData();
                        MessageBox.Show("Клиент успешно изменен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось изменить киента.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при изменении клиента: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        private void DeleteCustomers_Click(object sender, EventArgs e)
        {
            if (dataGridViewCustomers.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите клинта для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewCustomers.SelectedRows[0].Index;
            int ClientId = Convert.ToInt32(dataGridViewCustomers.Rows[selectedIndex].Cells["Клиент_ID"].Value);

            if (MessageBox.Show("Вы уверены, что хотите удалить киента с кодом " + ClientId + "?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Клиенты WHERE Клиент_ID = @ClientId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ClientId", ClientId);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        MessageBox.Show("Клиент успешно удален.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении клиента: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }


        private void ClearInputFields()
        {

            textBoxNameOrg.Text = "";
            textBoxAdress.Text = "";
            textBoxContactName.Text = "";
            textBoxPhone.Text = "";
        }

        private void textBoxClentID_TextChanged(object sender, EventArgs e)
        {

        }

        private void CustomersForm_Load(object sender, EventArgs e)
        {

        }

        
    }
}
