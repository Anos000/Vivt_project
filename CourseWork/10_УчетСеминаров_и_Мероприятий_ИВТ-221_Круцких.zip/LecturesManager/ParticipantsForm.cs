﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LecturesManager
{
    public partial class ParticipantsForm : Form
    {
        private string connectionString;
        private SqlDataAdapter adapter;
        private DataTable dataTable;

        public ParticipantsForm(string connectionString)
        {
            InitializeComponent();

            comboBoxType.Items.Add("Автор");
            comboBoxType.Items.Add("Лектор");

            this.connectionString = connectionString;
            fetchData();

        }

        private void fetchData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Участник_ID, Имя, Фамилия, Email, Телефон, Тип_участника FROM Участники";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ApplyCellStyle(dataGridViewParticipants);
                    dataGridViewParticipants.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о участниках: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddParticipants_Click(object sender, EventArgs e)
        {
            

            string Name = textBoxName.Text;
            string Surname = textBoxSurname.Text;
            string EmaIl = textBoxEmail.Text;
            string phone = textBoxPhone.Text;
            string type = (string)comboBoxType.SelectedItem;

            if ((textBoxName.Text == "") || (textBoxSurname.Text == "") || (textBoxEmail.Text == "") || (textBoxPhone.Text == "") || ((string)comboBoxType.SelectedItem == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }


                using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Участники (Имя, Фамилия, Email, Телефон, Тип_участника) VALUES (@Name, @Surname, @EmaIl, @phone, @type)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Surname", Surname);
                command.Parameters.AddWithValue("@EmaIl", EmaIl);
                command.Parameters.AddWithValue("@phone", phone);
                command.Parameters.AddWithValue("@type", type);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    fetchData();
                    ClearInputFields();
                    MessageBox.Show("Участник успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении участника: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UpdateParticipants_Click(object sender, EventArgs e)
        {
            if (dataGridViewParticipants.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите участника для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewParticipants.SelectedRows[0].Index;
            int ParticipantId = Convert.ToInt32(dataGridViewParticipants.Rows[selectedIndex].Cells["Участник_ID"].Value);

            string Name = textBoxName.Text;
            string Surname = textBoxSurname.Text;
            string EmaIl = textBoxEmail.Text;
            string phone = textBoxPhone.Text;
            string type = (string)comboBoxType.SelectedItem;

            if ((textBoxName.Text == "") || (textBoxSurname.Text == "") || (textBoxEmail.Text == "") || (textBoxPhone.Text == "") || ((string)comboBoxType.SelectedItem == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Участники SET  Имя = @Name, Фамилия = @Surname, Email = @EmaIl, Телефон = @phone, Тип_участника = @type  WHERE Участник_ID = @ParticipantId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ParticipantId", ParticipantId);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Surname", Surname);
                command.Parameters.AddWithValue("@EmaIl", EmaIl);
                command.Parameters.AddWithValue("@phone", phone);
                command.Parameters.AddWithValue("@type", type);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        fetchData();
                        MessageBox.Show("Участник успешно изменен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось изменить участника.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при изменении учатника: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        private void DeleteParticipants_Click(object sender, EventArgs e)
        {
            if (dataGridViewParticipants.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите участника для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewParticipants.SelectedRows[0].Index;
            int ParticipantId = Convert.ToInt32(dataGridViewParticipants.Rows[selectedIndex].Cells["Участник_ID"].Value);

            if (MessageBox.Show("Вы уверены, что хотите удалить участника с кодом " + ParticipantId + "?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Участники WHERE Участник_ID = @ParticipantId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ParticipantId", ParticipantId);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        MessageBox.Show("Участник успешно удален.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении участника: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ClearInputFields()
        {
            textBoxName.Text = "";
            textBoxSurname.Text = "";
            textBoxEmail.Text = "";
            textBoxPhone.Text = "";
        }





        static public void ApplyCellStyle(DataGridView dataGridView)
        {
            dataGridView.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
            dataGridView.BorderStyle = BorderStyle.FixedSingle;
        }

        private void ParticipantsForm_Load(object sender, EventArgs e)
        {

        }

        private void comboBoxType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        
    }
}
