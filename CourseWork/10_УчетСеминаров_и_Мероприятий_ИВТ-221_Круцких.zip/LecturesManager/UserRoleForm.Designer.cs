﻿namespace LecturesManager
{
    partial class UserRoleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            tabControl1 = new TabControl();
            Мероприятия = new TabPage();
            dataGridViewEventsUser = new DataGridView();
            Посещения = new TabPage();
            dataGridViewVisitsUser = new DataGridView();
            Темы_выступлений = new TabPage();
            dataGridViewThemesUser = new DataGridView();
            Участники = new TabPage();
            dataGridViewParticipantsUser = new DataGridView();
            Клиенты = new TabPage();
            dataGridViewCustomersUser = new DataGridView();
            Договоры = new TabPage();
            dataGridViewContractsUser = new DataGridView();
            tabControl2 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            tabControl3 = new TabControl();
            tabPage3 = new TabPage();
            dataGridView1 = new DataGridView();
            tabPage4 = new TabPage();
            dataGridView2 = new DataGridView();
            tabPage5 = new TabPage();
            dataGridView3 = new DataGridView();
            button9 = new Button();
            button8 = new Button();
            tabControl1.SuspendLayout();
            Мероприятия.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewEventsUser).BeginInit();
            Посещения.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewVisitsUser).BeginInit();
            Темы_выступлений.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewThemesUser).BeginInit();
            Участники.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewParticipantsUser).BeginInit();
            Клиенты.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomersUser).BeginInit();
            Договоры.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewContractsUser).BeginInit();
            tabControl2.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabControl3.SuspendLayout();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(228, 9);
            label1.Name = "label1";
            label1.Size = new Size(459, 38);
            label1.TabIndex = 0;
            label1.Text = "Учет семинаров и мероприятий";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Мероприятия);
            tabControl1.Controls.Add(Посещения);
            tabControl1.Controls.Add(Темы_выступлений);
            tabControl1.Controls.Add(Участники);
            tabControl1.Controls.Add(Клиенты);
            tabControl1.Controls.Add(Договоры);
            tabControl1.Location = new Point(-4, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1011, 441);
            tabControl1.TabIndex = 1;
            // 
            // Мероприятия
            // 
            Мероприятия.Controls.Add(dataGridViewEventsUser);
            Мероприятия.Location = new Point(4, 24);
            Мероприятия.Name = "Мероприятия";
            Мероприятия.Padding = new Padding(3);
            Мероприятия.Size = new Size(1003, 413);
            Мероприятия.TabIndex = 0;
            Мероприятия.Text = "Мероприятия";
            Мероприятия.UseVisualStyleBackColor = true;
            // 
            // dataGridViewEventsUser
            // 
            dataGridViewEventsUser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewEventsUser.Dock = DockStyle.Fill;
            dataGridViewEventsUser.Location = new Point(3, 3);
            dataGridViewEventsUser.Name = "dataGridViewEventsUser";
            dataGridViewEventsUser.RowTemplate.Height = 25;
            dataGridViewEventsUser.Size = new Size(997, 407);
            dataGridViewEventsUser.TabIndex = 0;
            // 
            // Посещения
            // 
            Посещения.Controls.Add(dataGridViewVisitsUser);
            Посещения.Location = new Point(4, 24);
            Посещения.Name = "Посещения";
            Посещения.Padding = new Padding(3);
            Посещения.Size = new Size(1003, 413);
            Посещения.TabIndex = 1;
            Посещения.Text = "Посещения";
            Посещения.UseVisualStyleBackColor = true;
            // 
            // dataGridViewVisitsUser
            // 
            dataGridViewVisitsUser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewVisitsUser.Dock = DockStyle.Fill;
            dataGridViewVisitsUser.Location = new Point(3, 3);
            dataGridViewVisitsUser.Name = "dataGridViewVisitsUser";
            dataGridViewVisitsUser.RowTemplate.Height = 25;
            dataGridViewVisitsUser.Size = new Size(997, 407);
            dataGridViewVisitsUser.TabIndex = 0;
            // 
            // Темы_выступлений
            // 
            Темы_выступлений.Controls.Add(dataGridViewThemesUser);
            Темы_выступлений.Location = new Point(4, 24);
            Темы_выступлений.Name = "Темы_выступлений";
            Темы_выступлений.Size = new Size(1003, 413);
            Темы_выступлений.TabIndex = 2;
            Темы_выступлений.Text = "Темы_выступлений";
            Темы_выступлений.UseVisualStyleBackColor = true;
            // 
            // dataGridViewThemesUser
            // 
            dataGridViewThemesUser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewThemesUser.Dock = DockStyle.Fill;
            dataGridViewThemesUser.Location = new Point(0, 0);
            dataGridViewThemesUser.Name = "dataGridViewThemesUser";
            dataGridViewThemesUser.RowTemplate.Height = 25;
            dataGridViewThemesUser.Size = new Size(1003, 413);
            dataGridViewThemesUser.TabIndex = 0;
            // 
            // Участники
            // 
            Участники.Controls.Add(dataGridViewParticipantsUser);
            Участники.Location = new Point(4, 24);
            Участники.Name = "Участники";
            Участники.Size = new Size(1003, 413);
            Участники.TabIndex = 3;
            Участники.Text = "Участники";
            Участники.UseVisualStyleBackColor = true;
            // 
            // dataGridViewParticipantsUser
            // 
            dataGridViewParticipantsUser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewParticipantsUser.Dock = DockStyle.Fill;
            dataGridViewParticipantsUser.Location = new Point(0, 0);
            dataGridViewParticipantsUser.Name = "dataGridViewParticipantsUser";
            dataGridViewParticipantsUser.RowTemplate.Height = 25;
            dataGridViewParticipantsUser.Size = new Size(1003, 413);
            dataGridViewParticipantsUser.TabIndex = 0;
            // 
            // Клиенты
            // 
            Клиенты.Controls.Add(dataGridViewCustomersUser);
            Клиенты.Location = new Point(4, 24);
            Клиенты.Name = "Клиенты";
            Клиенты.Size = new Size(1003, 413);
            Клиенты.TabIndex = 4;
            Клиенты.Text = "Клиенты";
            Клиенты.UseVisualStyleBackColor = true;
            // 
            // dataGridViewCustomersUser
            // 
            dataGridViewCustomersUser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCustomersUser.Dock = DockStyle.Fill;
            dataGridViewCustomersUser.Location = new Point(0, 0);
            dataGridViewCustomersUser.Name = "dataGridViewCustomersUser";
            dataGridViewCustomersUser.RowTemplate.Height = 25;
            dataGridViewCustomersUser.Size = new Size(1003, 413);
            dataGridViewCustomersUser.TabIndex = 0;
            // 
            // Договоры
            // 
            Договоры.Controls.Add(dataGridViewContractsUser);
            Договоры.Location = new Point(4, 24);
            Договоры.Name = "Договоры";
            Договоры.Size = new Size(1003, 413);
            Договоры.TabIndex = 5;
            Договоры.Text = "Договоры";
            Договоры.UseVisualStyleBackColor = true;
            // 
            // dataGridViewContractsUser
            // 
            dataGridViewContractsUser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewContractsUser.Dock = DockStyle.Fill;
            dataGridViewContractsUser.Location = new Point(0, 0);
            dataGridViewContractsUser.Name = "dataGridViewContractsUser";
            dataGridViewContractsUser.RowTemplate.Height = 25;
            dataGridViewContractsUser.Size = new Size(1003, 413);
            dataGridViewContractsUser.TabIndex = 0;
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(tabPage1);
            tabControl2.Controls.Add(tabPage2);
            tabControl2.Location = new Point(12, 43);
            tabControl2.Name = "tabControl2";
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new Size(938, 465);
            tabControl2.TabIndex = 2;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(tabControl1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(930, 437);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Формы";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(tabControl3);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(930, 437);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Отчеты";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            tabControl3.Controls.Add(tabPage3);
            tabControl3.Controls.Add(tabPage4);
            tabControl3.Controls.Add(tabPage5);
            tabControl3.Location = new Point(-4, 0);
            tabControl3.Name = "tabControl3";
            tabControl3.SelectedIndex = 0;
            tabControl3.Size = new Size(938, 441);
            tabControl3.TabIndex = 0;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(dataGridView1);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(930, 413);
            tabPage3.TabIndex = 0;
            tabPage3.Text = "Договоры суммой больше 70к";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(3, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(924, 407);
            dataGridView1.TabIndex = 0;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(dataGridView2);
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(930, 413);
            tabPage4.TabIndex = 1;
            tabPage4.Text = "Темы по индефикатору мероприятия номер 1";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Dock = DockStyle.Fill;
            dataGridView2.Location = new Point(3, 3);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowTemplate.Height = 25;
            dataGridView2.Size = new Size(924, 407);
            dataGridView2.TabIndex = 0;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(dataGridView3);
            tabPage5.Location = new Point(4, 24);
            tabPage5.Name = "tabPage5";
            tabPage5.Size = new Size(930, 413);
            tabPage5.TabIndex = 2;
            tabPage5.Text = "ID Администраторов";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Dock = DockStyle.Fill;
            dataGridView3.Location = new Point(0, 0);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowTemplate.Height = 25;
            dataGridView3.Size = new Size(930, 413);
            dataGridView3.TabIndex = 0;
            // 
            // button9
            // 
            button9.Location = new Point(837, 545);
            button9.Name = "button9";
            button9.Size = new Size(113, 23);
            button9.TabIndex = 12;
            button9.Text = "Выход";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button8
            // 
            button8.Location = new Point(837, 578);
            button8.Name = "button8";
            button8.Size = new Size(113, 23);
            button8.TabIndex = 13;
            button8.Text = "О программе";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // UserRoleForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(962, 613);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(tabControl2);
            Controls.Add(label1);
            Name = "UserRoleForm";
            Text = "UserRoleForm";
            Load += UserRoleForm_Load;
            tabControl1.ResumeLayout(false);
            Мероприятия.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewEventsUser).EndInit();
            Посещения.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewVisitsUser).EndInit();
            Темы_выступлений.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewThemesUser).EndInit();
            Участники.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewParticipantsUser).EndInit();
            Клиенты.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomersUser).EndInit();
            Договоры.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewContractsUser).EndInit();
            tabControl2.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabControl3.ResumeLayout(false);
            tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TabControl tabControl1;
        private TabPage Мероприятия;
        private TabPage Посещения;
        private TabPage Темы_выступлений;
        private TabPage Участники;
        private TabPage Клиенты;
        private TabPage Договоры;
        private DataGridView dataGridViewVisitsUser;
        private DataGridView dataGridViewEventsUser;
        private DataGridView dataGridViewThemesUser;
        private DataGridView dataGridViewParticipantsUser;
        private DataGridView dataGridViewCustomersUser;
        private DataGridView dataGridViewContractsUser;
        private TabControl tabControl2;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabControl tabControl3;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private TabPage tabPage5;
        private DataGridView dataGridView3;
        private Button button9;
        private Button button8;
    }
}