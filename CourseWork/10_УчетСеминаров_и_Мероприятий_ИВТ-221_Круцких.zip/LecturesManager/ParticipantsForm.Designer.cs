﻿namespace LecturesManager
{
    partial class ParticipantsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewParticipants = new DataGridView();
            Name = new Label();
            Surname = new Label();
            Email = new Label();
            Phone = new Label();
            Type = new Label();
            textBoxName = new TextBox();
            textBoxSurname = new TextBox();
            textBoxEmail = new TextBox();
            textBoxPhone = new TextBox();
            comboBoxType = new ComboBox();
            AddParticipants = new Button();
            UpdateParticipants = new Button();
            DeleteParticipants = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewParticipants).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewParticipants
            // 
            dataGridViewParticipants.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewParticipants.Location = new Point(281, 12);
            dataGridViewParticipants.Name = "dataGridViewParticipants";
            dataGridViewParticipants.RowTemplate.Height = 25;
            dataGridViewParticipants.Size = new Size(507, 426);
            dataGridViewParticipants.TabIndex = 0;
            // 
            // Name
            // 
            Name.AutoSize = true;
            Name.Location = new Point(84, 70);
            Name.Name = "Name";
            Name.Size = new Size(31, 15);
            Name.TabIndex = 2;
            Name.Text = "Имя";
            // 
            // Surname
            // 
            Surname.AutoSize = true;
            Surname.Location = new Point(57, 102);
            Surname.Name = "Surname";
            Surname.Size = new Size(58, 15);
            Surname.TabIndex = 3;
            Surname.Text = "Фамилия";
            // 
            // Email
            // 
            Email.AutoSize = true;
            Email.Location = new Point(79, 134);
            Email.Name = "Email";
            Email.Size = new Size(36, 15);
            Email.TabIndex = 4;
            Email.Text = "Email";
            // 
            // Phone
            // 
            Phone.AutoSize = true;
            Phone.Location = new Point(60, 166);
            Phone.Name = "Phone";
            Phone.Size = new Size(55, 15);
            Phone.TabIndex = 5;
            Phone.Text = "Телефон";
            // 
            // Type
            // 
            Type.AutoSize = true;
            Type.Location = new Point(29, 203);
            Type.Name = "Type";
            Type.Size = new Size(86, 15);
            Type.TabIndex = 6;
            Type.Text = "Тип участника";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(136, 67);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(139, 23);
            textBoxName.TabIndex = 8;
            // 
            // textBoxSurname
            // 
            textBoxSurname.Location = new Point(136, 99);
            textBoxSurname.Name = "textBoxSurname";
            textBoxSurname.Size = new Size(139, 23);
            textBoxSurname.TabIndex = 9;
            // 
            // textBoxEmail
            // 
            textBoxEmail.Location = new Point(136, 131);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(139, 23);
            textBoxEmail.TabIndex = 10;
            // 
            // textBoxPhone
            // 
            textBoxPhone.Location = new Point(136, 163);
            textBoxPhone.Name = "textBoxPhone";
            textBoxPhone.Size = new Size(139, 23);
            textBoxPhone.TabIndex = 11;
            // 
            // comboBoxType
            // 
            comboBoxType.FormattingEnabled = true;
            comboBoxType.Location = new Point(136, 200);
            comboBoxType.Name = "comboBoxType";
            comboBoxType.Size = new Size(139, 23);
            comboBoxType.TabIndex = 12;
            comboBoxType.SelectedIndexChanged += comboBoxType_SelectedIndexChanged;
            // 
            // AddParticipants
            // 
            AddParticipants.Location = new Point(98, 250);
            AddParticipants.Name = "AddParticipants";
            AddParticipants.Size = new Size(89, 23);
            AddParticipants.TabIndex = 13;
            AddParticipants.Text = "Добавить";
            AddParticipants.UseVisualStyleBackColor = true;
            AddParticipants.Click += AddParticipants_Click;
            // 
            // UpdateParticipants
            // 
            UpdateParticipants.Location = new Point(98, 279);
            UpdateParticipants.Name = "UpdateParticipants";
            UpdateParticipants.Size = new Size(89, 23);
            UpdateParticipants.TabIndex = 14;
            UpdateParticipants.Text = "Обновить";
            UpdateParticipants.UseVisualStyleBackColor = true;
            UpdateParticipants.Click += UpdateParticipants_Click;
            // 
            // DeleteParticipants
            // 
            DeleteParticipants.Location = new Point(98, 308);
            DeleteParticipants.Name = "DeleteParticipants";
            DeleteParticipants.Size = new Size(89, 23);
            DeleteParticipants.TabIndex = 15;
            DeleteParticipants.Text = "Удалить";
            DeleteParticipants.UseVisualStyleBackColor = true;
            DeleteParticipants.Click += DeleteParticipants_Click;
            // 
            // ParticipantsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteParticipants);
            Controls.Add(UpdateParticipants);
            Controls.Add(AddParticipants);
            Controls.Add(comboBoxType);
            Controls.Add(textBoxPhone);
            Controls.Add(textBoxEmail);
            Controls.Add(textBoxSurname);
            Controls.Add(textBoxName);
            Controls.Add(Type);
            Controls.Add(Phone);
            Controls.Add(Email);
            Controls.Add(Surname);
            Controls.Add(Name);
            Controls.Add(dataGridViewParticipants);

            Text = "Участники";
            Load += ParticipantsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewParticipants).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewParticipants;
        private Label Name;
        private Label Surname;
        private Label Email;
        private Label Phone;
        private Label Type;
        private TextBox textBoxName;
        private TextBox textBoxSurname;
        private TextBox textBoxEmail;
        private TextBox textBoxPhone;
        private ComboBox comboBoxType;
        private Button AddParticipants;
        private Button UpdateParticipants;
        private Button DeleteParticipants;
    }
}