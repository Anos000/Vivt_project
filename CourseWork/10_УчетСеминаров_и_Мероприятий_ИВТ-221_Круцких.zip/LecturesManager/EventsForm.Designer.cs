﻿namespace LecturesManager
{
    partial class EventsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewEvents = new DataGridView();
            NameEvents = new Label();
            DataStart = new Label();
            DataEnd = new Label();
            Note = new Label();
            textBoxNameEvents = new TextBox();
            dateTimePickerDataStart = new DateTimePicker();
            dateTimePickerDataEnd = new DateTimePicker();
            textBoxNote = new TextBox();
            AddEvents = new Button();
            UpdateEvents = new Button();
            DeleteEvents = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewEvents).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewEvents
            // 
            dataGridViewEvents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewEvents.Location = new Point(296, 12);
            dataGridViewEvents.Name = "dataGridViewEvents";
            dataGridViewEvents.RowTemplate.Height = 25;
            dataGridViewEvents.Size = new Size(492, 426);
            dataGridViewEvents.TabIndex = 0;
            // 
            // NameEvents
            // 
            NameEvents.AutoSize = true;
            NameEvents.Location = new Point(12, 43);
            NameEvents.Name = "NameEvents";
            NameEvents.Size = new Size(136, 15);
            NameEvents.TabIndex = 2;
            NameEvents.Text = "Названия мероприятия";
            // 
            // DataStart
            // 
            DataStart.AutoSize = true;
            DataStart.Location = new Point(74, 78);
            DataStart.Name = "DataStart";
            DataStart.Size = new Size(74, 15);
            DataStart.TabIndex = 3;
            DataStart.Text = "Дата начала";
            // 
            // DataEnd
            // 
            DataEnd.AutoSize = true;
            DataEnd.Location = new Point(53, 111);
            DataEnd.Name = "DataEnd";
            DataEnd.Size = new Size(95, 15);
            DataEnd.TabIndex = 4;
            DataEnd.Text = "Дата окончания";
            // 
            // Note
            // 
            Note.AutoSize = true;
            Note.Location = new Point(86, 141);
            Note.Name = "Note";
            Note.Size = new Size(62, 15);
            Note.TabIndex = 5;
            Note.Text = "Описание";
            // 
            // textBoxNameEvents
            // 
            textBoxNameEvents.Location = new Point(154, 38);
            textBoxNameEvents.Name = "textBoxNameEvents";
            textBoxNameEvents.Size = new Size(136, 23);
            textBoxNameEvents.TabIndex = 7;
            // 
            // dateTimePickerDataStart
            // 
            dateTimePickerDataStart.Location = new Point(154, 72);
            dateTimePickerDataStart.Name = "dateTimePickerDataStart";
            dateTimePickerDataStart.Size = new Size(136, 23);
            dateTimePickerDataStart.TabIndex = 8;
            // 
            // dateTimePickerDataEnd
            // 
            dateTimePickerDataEnd.Location = new Point(154, 105);
            dateTimePickerDataEnd.Name = "dateTimePickerDataEnd";
            dateTimePickerDataEnd.Size = new Size(136, 23);
            dateTimePickerDataEnd.TabIndex = 9;
            // 
            // textBoxNote
            // 
            textBoxNote.Location = new Point(154, 138);
            textBoxNote.Name = "textBoxNote";
            textBoxNote.Size = new Size(136, 23);
            textBoxNote.TabIndex = 10;
            // 
            // AddEvents
            // 
            AddEvents.Location = new Point(108, 203);
            AddEvents.Name = "AddEvents";
            AddEvents.Size = new Size(89, 23);
            AddEvents.TabIndex = 11;
            AddEvents.Text = "Добавить";
            AddEvents.UseVisualStyleBackColor = true;
            AddEvents.Click += AddEvents_Click;
            // 
            // UpdateEvents
            // 
            UpdateEvents.Location = new Point(108, 232);
            UpdateEvents.Name = "UpdateEvents";
            UpdateEvents.Size = new Size(89, 23);
            UpdateEvents.TabIndex = 12;
            UpdateEvents.Text = "Обновить";
            UpdateEvents.UseVisualStyleBackColor = true;
            UpdateEvents.Click += UpdateEvents_Click;
            // 
            // DeleteEvents
            // 
            DeleteEvents.Location = new Point(108, 261);
            DeleteEvents.Name = "DeleteEvents";
            DeleteEvents.Size = new Size(89, 23);
            DeleteEvents.TabIndex = 13;
            DeleteEvents.Text = "Удалить";
            DeleteEvents.UseVisualStyleBackColor = true;
            DeleteEvents.Click += DeleteEvents_Click;
            // 
            // EventsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteEvents);
            Controls.Add(UpdateEvents);
            Controls.Add(AddEvents);
            Controls.Add(textBoxNote);
            Controls.Add(dateTimePickerDataEnd);
            Controls.Add(dateTimePickerDataStart);
            Controls.Add(textBoxNameEvents);
            Controls.Add(Note);
            Controls.Add(DataEnd);
            Controls.Add(DataStart);
            Controls.Add(NameEvents);
            Controls.Add(dataGridViewEvents);
            Name = "EventsForm";
            Text = "Мероприятия";
            Load += EventsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewEvents).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewEvents;
        private Label NameEvents;
        private Label DataStart;
        private Label DataEnd;
        private Label Note;
        private TextBox textBoxNameEvents;
        private DateTimePicker dateTimePickerDataStart;
        private DateTimePicker dateTimePickerDataEnd;
        private TextBox textBoxNote;
        private Button AddEvents;
        private Button UpdateEvents;
        private Button DeleteEvents;
    }
}