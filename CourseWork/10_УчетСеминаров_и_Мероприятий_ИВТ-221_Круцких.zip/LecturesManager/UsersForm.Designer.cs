﻿namespace LecturesManager
{
    partial class UsersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewuser = new DataGridView();
            Login = new Label();
            Password = new Label();
            Role = new Label();
            comboBoxRole = new ComboBox();
            textPassword = new TextBox();
            textBoxLogin = new TextBox();
            AddUsers = new Button();
            UpdateUsers = new Button();
            DeleteUsers = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewuser).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewuser
            // 
            dataGridViewuser.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewuser.Location = new Point(298, 12);
            dataGridViewuser.Name = "dataGridViewuser";
            dataGridViewuser.RowTemplate.Height = 25;
            dataGridViewuser.Size = new Size(490, 426);
            dataGridViewuser.TabIndex = 0;
            // 
            // Login
            // 
            Login.AutoSize = true;
            Login.Location = new Point(81, 72);
            Login.Name = "Login";
            Login.Size = new Size(41, 15);
            Login.TabIndex = 2;
            Login.Text = "Логин";
            Login.Click += Login_Click;
            // 
            // Password
            // 
            Password.AutoSize = true;
            Password.Location = new Point(73, 100);
            Password.Name = "Password";
            Password.Size = new Size(49, 15);
            Password.TabIndex = 3;
            Password.Text = "Пароль";
            // 
            // Role
            // 
            Role.AutoSize = true;
            Role.Location = new Point(88, 133);
            Role.Name = "Role";
            Role.Size = new Size(34, 15);
            Role.TabIndex = 4;
            Role.Text = "Роль";
            // 
            // comboBoxRole
            // 
            comboBoxRole.FormattingEnabled = true;
            comboBoxRole.Location = new Point(128, 133);
            comboBoxRole.Name = "comboBoxRole";
            comboBoxRole.Size = new Size(121, 23);
            comboBoxRole.TabIndex = 5;
            // 
            // textPassword
            // 
            textPassword.Location = new Point(128, 97);
            textPassword.Name = "textPassword";
            textPassword.Size = new Size(121, 23);
            textPassword.TabIndex = 6;
            // 
            // textBoxLogin
            // 
            textBoxLogin.Location = new Point(128, 67);
            textBoxLogin.Name = "textBoxLogin";
            textBoxLogin.Size = new Size(121, 23);
            textBoxLogin.TabIndex = 7;
            // 
            // AddUsers
            // 
            AddUsers.Location = new Point(108, 207);
            AddUsers.Name = "AddUsers";
            AddUsers.Size = new Size(92, 23);
            AddUsers.TabIndex = 9;
            AddUsers.Text = "Добавить";
            AddUsers.UseVisualStyleBackColor = true;
            AddUsers.Click += AddUsers_Click;
            // 
            // UpdateUsers
            // 
            UpdateUsers.Location = new Point(108, 236);
            UpdateUsers.Name = "UpdateUsers";
            UpdateUsers.Size = new Size(92, 23);
            UpdateUsers.TabIndex = 10;
            UpdateUsers.Text = "Обновить";
            UpdateUsers.UseVisualStyleBackColor = true;
            UpdateUsers.Click += UpdateUsers_Click;
            // 
            // DeleteUsers
            // 
            DeleteUsers.Location = new Point(108, 265);
            DeleteUsers.Name = "DeleteUsers";
            DeleteUsers.Size = new Size(92, 23);
            DeleteUsers.TabIndex = 11;
            DeleteUsers.Text = "Удалить";
            DeleteUsers.UseVisualStyleBackColor = true;
            DeleteUsers.Click += DeleteUsers_Click;
            // 
            // UsersForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteUsers);
            Controls.Add(UpdateUsers);
            Controls.Add(AddUsers);
            Controls.Add(textBoxLogin);
            Controls.Add(textPassword);
            Controls.Add(comboBoxRole);
            Controls.Add(Role);
            Controls.Add(Password);
            Controls.Add(Login);
            Controls.Add(dataGridViewuser);
            Name = "UsersForm";
            Text = "Пользователи";
            Load += UsersForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewuser).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewuser;
        private Label Login;
        private Label Password;
        private Label Role;
        private ComboBox comboBoxRole;
        private TextBox textPassword;
        private TextBox textBoxLogin;
        private Button AddUsers;
        private Button UpdateUsers;
        private Button DeleteUsers;
    }
}