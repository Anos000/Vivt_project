﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LecturesManager
{
    public partial class UsersForm : Form
    {
        private string connectionString;
        private SqlDataAdapter adapter;
        private DataTable dataTable;

        public UsersForm(string connectionString)
        {
            InitializeComponent();

            comboBoxRole.Items.Add("Администратор");
            comboBoxRole.Items.Add("Пользователь");

            this.connectionString = connectionString;
            fetchData();

        }

        private void fetchData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Пользователь_ID, Логин, Пароль, Роль FROM Пользователи";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ApplyCellStyle(dataGridViewuser);
                    dataGridViewuser.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о пользователх: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddUsers_Click(object sender, EventArgs e)
        {

            string login = textBoxLogin.Text;
            string password = textPassword.Text;
            string type = (string)comboBoxRole.SelectedItem;

            if ((textBoxLogin.Text == "") || (textPassword.Text == "") || ((string)comboBoxRole.SelectedItem == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Пользователи (Логин, Пароль, Роль) VALUES (@login, @password, @type)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@login", login);
                command.Parameters.AddWithValue("@password", password);
                command.Parameters.AddWithValue("@type", type);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    fetchData();
                    ClearInputFields();
                    MessageBox.Show("Пользователь успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении пользователя: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UpdateUsers_Click(object sender, EventArgs e)
        {
            if (dataGridViewuser.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите пользователя для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewuser.SelectedRows[0].Index;
            int UserId = Convert.ToInt32(dataGridViewuser.Rows[selectedIndex].Cells["Пользователь_ID"].Value);

            string login = textBoxLogin.Text;
            string password = textPassword.Text;
            string type = (string)comboBoxRole.SelectedItem;

            if ((textBoxLogin.Text == "") || (textPassword.Text == "") || ((string)comboBoxRole.SelectedItem == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Пользователи SET  Логин = @login, Пароль = @password, Роль = @type  WHERE Пользователь_ID = @UserId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", UserId);
                command.Parameters.AddWithValue("@login", login);
                command.Parameters.AddWithValue("@password", password);
                command.Parameters.AddWithValue("@type", type);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        fetchData();
                        MessageBox.Show("Пользователь успешно изменен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось изменить поьзователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при изменении поьзователя: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DeleteUsers_Click(object sender, EventArgs e)
        {
            if (dataGridViewuser.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите пользователя для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewuser.SelectedRows[0].Index;
            int UserId = Convert.ToInt32(dataGridViewuser.Rows[selectedIndex].Cells["Пользователь_ID"].Value);

            if (MessageBox.Show("Вы уверены, что хотите удалить пользователя с кодом " + UserId + "?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Пользователи WHERE Пользователь_ID = @UserId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserId", UserId);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        MessageBox.Show("Пользователь успешно удален.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении пользователя: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ClearInputFields()
        {
            textBoxLogin.Text = "";
            textPassword.Text = "";
        }

        static public void ApplyCellStyle(DataGridView dataGridView)
        {
            dataGridView.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
            dataGridView.BorderStyle = BorderStyle.FixedSingle;
        }

        private void Login_Click(object sender, EventArgs e)
        {

        }

        private void UsersID_Click(object sender, EventArgs e)
        {

        }

        private void UsersForm_Load(object sender, EventArgs e)
        {

        }

        
    }
}
