﻿namespace LecturesManager
{
    partial class CustomersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewCustomers = new DataGridView();
            NameOrg = new Label();
            Adress = new Label();
            ContactName = new Label();
            Phone = new Label();
            textBoxNameOrg = new TextBox();
            textBoxAdress = new TextBox();
            textBoxContactName = new TextBox();
            textBoxPhone = new TextBox();
            AddCustomers = new Button();
            UpdateCustomers = new Button();
            DeleteCustomers = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewCustomers
            // 
            dataGridViewCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCustomers.Location = new Point(307, 12);
            dataGridViewCustomers.Name = "dataGridViewCustomers";
            dataGridViewCustomers.RowTemplate.Height = 25;
            dataGridViewCustomers.Size = new Size(481, 426);
            dataGridViewCustomers.TabIndex = 0;
            // 
            // NameOrg
            // 
            NameOrg.AutoSize = true;
            NameOrg.Location = new Point(12, 61);
            NameOrg.Name = "NameOrg";
            NameOrg.Size = new Size(133, 15);
            NameOrg.TabIndex = 2;
            NameOrg.Text = "Название организации";
            // 
            // Adress
            // 
            Adress.AutoSize = true;
            Adress.Location = new Point(105, 89);
            Adress.Name = "Adress";
            Adress.Size = new Size(40, 15);
            Adress.TabIndex = 3;
            Adress.Text = "Адрес";
            // 
            // ContactName
            // 
            ContactName.AutoSize = true;
            ContactName.Location = new Point(44, 117);
            ContactName.Name = "ContactName";
            ContactName.Size = new Size(101, 15);
            ContactName.TabIndex = 4;
            ContactName.Text = "Контактное лицо";
            // 
            // Phone
            // 
            Phone.AutoSize = true;
            Phone.Location = new Point(90, 150);
            Phone.Name = "Phone";
            Phone.Size = new Size(55, 15);
            Phone.TabIndex = 5;
            Phone.Text = "Телефон";
            // 
            // textBoxNameOrg
            // 
            textBoxNameOrg.Location = new Point(151, 58);
            textBoxNameOrg.Name = "textBoxNameOrg";
            textBoxNameOrg.Size = new Size(150, 23);
            textBoxNameOrg.TabIndex = 7;
            // 
            // textBoxAdress
            // 
            textBoxAdress.Location = new Point(151, 86);
            textBoxAdress.Name = "textBoxAdress";
            textBoxAdress.Size = new Size(150, 23);
            textBoxAdress.TabIndex = 8;
            // 
            // textBoxContactName
            // 
            textBoxContactName.Location = new Point(151, 114);
            textBoxContactName.Name = "textBoxContactName";
            textBoxContactName.Size = new Size(150, 23);
            textBoxContactName.TabIndex = 9;
            // 
            // textBoxPhone
            // 
            textBoxPhone.Location = new Point(151, 147);
            textBoxPhone.Name = "textBoxPhone";
            textBoxPhone.Size = new Size(150, 23);
            textBoxPhone.TabIndex = 10;
            // 
            // AddCustomers
            // 
            AddCustomers.Location = new Point(105, 219);
            AddCustomers.Name = "AddCustomers";
            AddCustomers.Size = new Size(92, 23);
            AddCustomers.TabIndex = 11;
            AddCustomers.Text = "Добавить";
            AddCustomers.UseVisualStyleBackColor = true;
            AddCustomers.Click += AddCustomers_Click;
            // 
            // UpdateCustomers
            // 
            UpdateCustomers.Location = new Point(105, 248);
            UpdateCustomers.Name = "UpdateCustomers";
            UpdateCustomers.Size = new Size(92, 23);
            UpdateCustomers.TabIndex = 12;
            UpdateCustomers.Text = "Обновить";
            UpdateCustomers.UseVisualStyleBackColor = true;
            UpdateCustomers.Click += UpdateCustomers_Click;
            // 
            // DeleteCustomers
            // 
            DeleteCustomers.Location = new Point(105, 277);
            DeleteCustomers.Name = "DeleteCustomers";
            DeleteCustomers.Size = new Size(92, 23);
            DeleteCustomers.TabIndex = 13;
            DeleteCustomers.Text = "Удалить";
            DeleteCustomers.UseVisualStyleBackColor = true;
            DeleteCustomers.Click += DeleteCustomers_Click;
            // 
            // CustomersForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(DeleteCustomers);
            Controls.Add(UpdateCustomers);
            Controls.Add(AddCustomers);
            Controls.Add(textBoxPhone);
            Controls.Add(textBoxContactName);
            Controls.Add(textBoxAdress);
            Controls.Add(textBoxNameOrg);
            Controls.Add(Phone);
            Controls.Add(ContactName);
            Controls.Add(Adress);
            Controls.Add(NameOrg);
            Controls.Add(dataGridViewCustomers);
            Name = "CustomersForm";
            Text = "Клиенты";
            Load += CustomersForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewCustomers;
        private Label NameOrg;
        private Label Adress;
        private Label ContactName;
        private Label Phone;
        private TextBox textBoxNameOrg;
        private TextBox textBoxAdress;
        private TextBox textBoxContactName;
        private TextBox textBoxPhone;
        private Button AddCustomers;
        private Button UpdateCustomers;
        private Button DeleteCustomers;
    }
}