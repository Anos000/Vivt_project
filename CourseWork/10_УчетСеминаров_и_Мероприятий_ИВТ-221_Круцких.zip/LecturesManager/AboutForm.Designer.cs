﻿namespace LecturesManager
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            aboutlabel = new Label();
            SuspendLayout();
            // 
            // aboutlabel
            // 
            aboutlabel.AutoSize = true;
            aboutlabel.Location = new Point(22, 20);
            aboutlabel.Name = "aboutlabel";
            aboutlabel.Size = new Size(63, 15);
            aboutlabel.TabIndex = 0;
            aboutlabel.Text = "aboutlabel";
            aboutlabel.Click += aboutlabel_Click;
            // 
            // AboutForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(293, 89);
            Controls.Add(aboutlabel);
            Name = "AboutForm";
            Text = "AboutForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label aboutlabel;
    }
}