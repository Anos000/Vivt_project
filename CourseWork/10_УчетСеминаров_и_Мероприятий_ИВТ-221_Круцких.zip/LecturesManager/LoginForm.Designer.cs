﻿namespace LecturesManager
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            userName = new TextBox();
            password = new TextBox();
            label1 = new Label();
            label2 = new Label();
            loginButton = new Button();
            Outbutton = new Button();
            buttonProgram = new Button();
            SuspendLayout();
            // 
            // userName
            // 
            userName.Location = new Point(151, 48);
            userName.Name = "userName";
            userName.Size = new Size(182, 23);
            userName.TabIndex = 0;
            // 
            // password
            // 
            password.Location = new Point(151, 97);
            password.Name = "password";
            password.Size = new Size(182, 23);
            password.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(64, 56);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 2;
            label1.Text = "Логин:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(56, 105);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 3;
            label2.Text = "Пароль:";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // loginButton
            // 
            loginButton.Location = new Point(31, 151);
            loginButton.Name = "loginButton";
            loginButton.Size = new Size(302, 23);
            loginButton.TabIndex = 4;
            loginButton.Text = "Вход";
            loginButton.UseVisualStyleBackColor = true;
            loginButton.Click += loginButton_Click_1;
            // 
            // Outbutton
            // 
            Outbutton.Location = new Point(31, 180);
            Outbutton.Name = "Outbutton";
            Outbutton.Size = new Size(302, 23);
            Outbutton.TabIndex = 5;
            Outbutton.Text = "Выход";
            Outbutton.UseVisualStyleBackColor = true;
            Outbutton.Click += Outbutton_Click;
            // 
            // buttonProgram
            // 
            buttonProgram.Location = new Point(31, 228);
            buttonProgram.Name = "buttonProgram";
            buttonProgram.Size = new Size(113, 23);
            buttonProgram.TabIndex = 6;
            buttonProgram.Text = "О программе";
            buttonProgram.UseVisualStyleBackColor = true;
            buttonProgram.Click += buttonProgram_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(362, 278);
            Controls.Add(buttonProgram);
            Controls.Add(Outbutton);
            Controls.Add(loginButton);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(password);
            Controls.Add(userName);
            Name = "LoginForm";
            Text = "Login";
            Load += LoginForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox userName;
        private TextBox password;
        private Label label1;
        private Label label2;
        private Button loginButton;
        private Button Outbutton;
        private Button buttonProgram;
    }
}