﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LecturesManager
{
    public partial class EventsForm : Form
    {
        private string connectionString;
        private SqlDataAdapter adapter;
        private DataTable dataTable;

        public EventsForm(string connectionString)
        {
            InitializeComponent();
            this.connectionString = connectionString;
            fetchData();

        }

        private void fetchData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Мероприятие_ID, Название_мероприятия, Дата_начала, Дата_окончания, Описание FROM Мероприятия";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ApplyCellStyle(dataGridViewEvents);
                    dataGridViewEvents.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке отчета о мероприятиях: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static public void ApplyCellStyle(DataGridView dataGridView)
        {
            dataGridView.RowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
            dataGridView.BorderStyle = BorderStyle.FixedSingle;
        }

        private void AddEvents_Click(object sender, EventArgs e)
        {

            if ((textBoxNameEvents.Text == "") || (dateTimePickerDataStart.Value == DateTime.Now) || (dateTimePickerDataEnd.Value == DateTime.Now) || (textBoxNote.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;

            }
            string NameEvent = textBoxNameEvents.Text;
            DateTime DateStart = dateTimePickerDataStart.Value;
            DateTime DateEnd = dateTimePickerDataEnd.Value;
            string Note = textBoxNote.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Мероприятия (Название_мероприятия, Дата_начала, Дата_окончания, Описание) VALUES (@NameEvent, @DateStart, @DateEnd, @Note)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NameEvent", NameEvent);
                command.Parameters.AddWithValue("@DateStart", DateStart);
                command.Parameters.AddWithValue("@DateEnd", DateEnd);
                command.Parameters.AddWithValue("@Note", Note);
                if (DateStart < DateEnd) 
                {
                    try
                    {

                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        ClearInputFields();
                        MessageBox.Show("Мероприятие успешно добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при добавлении мероприятия: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
        }


        private void UpdateEvents_Click(object sender, EventArgs e)
        {
            if (dataGridViewEvents.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите договор для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            if ((textBoxNameEvents.Text == "") || (dateTimePickerDataStart.Value == DateTime.Now) || (dateTimePickerDataEnd.Value == DateTime.Now) || (textBoxNote.Text == ""))
            {
                MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;

            }

            int selectedIndex = dataGridViewEvents.SelectedRows[0].Index;
            int evetID = Convert.ToInt32(dataGridViewEvents.Rows[selectedIndex].Cells["Мероприятие_ID"].Value);

            string NameEvent = textBoxNameEvents.Text;
            DateTime DateStart = dateTimePickerDataStart.Value;
            DateTime DateEnd = dateTimePickerDataEnd.Value;
            string Note = textBoxNote.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Мероприятия SET Название_мероприятия = @NameEvent, Дата_начала = @DateStart, Дата_окончания = @DateEnd, Описание = @Note WHERE Мероприятие_ID = @evetID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@evetID", evetID);
                command.Parameters.AddWithValue("@NameEvent", NameEvent);
                command.Parameters.AddWithValue("@DateStart", DateStart);
                command.Parameters.AddWithValue("@DateEnd", DateEnd);
                command.Parameters.AddWithValue("@Note", Note);

                if ((textBoxNameEvents.Text != "") && (dateTimePickerDataStart.Value != DateTime.Now) && (dateTimePickerDataEnd.Value != DateTime.Now) && (textBoxNote.Text != ""))
                {
                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            fetchData();
                            MessageBox.Show("Мероприятие успешно изменено.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Не удалось изменить мероприятие.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при изменении мероприятия: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    MessageBox.Show("Проверьте введенные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


            }


        }

        private void DeleteEvents_Click(object sender, EventArgs e)
        {
            if (dataGridViewEvents.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Выберите клинта для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return;
            }

            int selectedIndex = dataGridViewEvents.SelectedRows[0].Index;
            int evetID = Convert.ToInt32(dataGridViewEvents.Rows[selectedIndex].Cells["Мероприятие_ID"].Value);

            if (MessageBox.Show("Вы уверены, что хотите удалить мероприятие с кодом " + evetID + "?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Мероприятия WHERE Мероприятие_ID = @evetID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@evetID", evetID);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        fetchData();
                        MessageBox.Show("Мероприятие успешно удалено.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении мероприяти: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ClearInputFields()
        {
            textBoxNameEvents.Text = "";
            dateTimePickerDataStart.Value = DateTime.Now;
            dateTimePickerDataEnd.Value = DateTime.Now;
            textBoxNote.Text = "";
        }

        private void EventsID_Click(object sender, EventArgs e)
        {

        }

        private void EventsForm_Load(object sender, EventArgs e)
        {

        }

        

        
    }
}
