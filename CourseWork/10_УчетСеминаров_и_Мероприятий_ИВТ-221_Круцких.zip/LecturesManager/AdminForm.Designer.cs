﻿namespace LecturesManager
{
    partial class AdminForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            tabControl1 = new TabControl();
            Пользователи = new TabPage();
            dataGridViewUsers = new DataGridView();
            Мероприятия = new TabPage();
            dataGridViewEvents = new DataGridView();
            Посещения = new TabPage();
            dataGridViewVisits = new DataGridView();
            Темы_выступлений = new TabPage();
            dataGridViewThemes = new DataGridView();
            Участники = new TabPage();
            dataGridViewParticipants = new DataGridView();
            Клиенты = new TabPage();
            dataGridViewCustomers = new DataGridView();
            Договоры = new TabPage();
            dataGridViewContracts = new DataGridView();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            tabControl2 = new TabControl();
            Формы = new TabPage();
            Отчеты = new TabPage();
            tabControl3 = new TabControl();
            tabPage1 = new TabPage();
            dataGridView1 = new DataGridView();
            tabPage2 = new TabPage();
            dataGridView2 = new DataGridView();
            tabPage3 = new TabPage();
            dataGridView3 = new DataGridView();
            button8 = new Button();
            button9 = new Button();
            tabControl1.SuspendLayout();
            Пользователи.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewUsers).BeginInit();
            Мероприятия.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewEvents).BeginInit();
            Посещения.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewVisits).BeginInit();
            Темы_выступлений.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewThemes).BeginInit();
            Участники.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewParticipants).BeginInit();
            Клиенты.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).BeginInit();
            Договоры.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewContracts).BeginInit();
            tabControl2.SuspendLayout();
            Формы.SuspendLayout();
            Отчеты.SuspendLayout();
            tabControl3.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(232, -2);
            label1.Name = "label1";
            label1.Size = new Size(459, 38);
            label1.TabIndex = 0;
            label1.Text = "Учет семинаров и мероприятий";
            label1.Click += label1_Click_1;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Пользователи);
            tabControl1.Controls.Add(Мероприятия);
            tabControl1.Controls.Add(Посещения);
            tabControl1.Controls.Add(Темы_выступлений);
            tabControl1.Controls.Add(Участники);
            tabControl1.Controls.Add(Клиенты);
            tabControl1.Controls.Add(Договоры);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(944, 431);
            tabControl1.TabIndex = 1;
            // 
            // Пользователи
            // 
            Пользователи.Controls.Add(dataGridViewUsers);
            Пользователи.Location = new Point(4, 24);
            Пользователи.Name = "Пользователи";
            Пользователи.Padding = new Padding(3);
            Пользователи.Size = new Size(936, 403);
            Пользователи.TabIndex = 0;
            Пользователи.Text = "Пользователи";
            Пользователи.UseVisualStyleBackColor = true;
            // 
            // dataGridViewUsers
            // 
            dataGridViewUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewUsers.Dock = DockStyle.Fill;
            dataGridViewUsers.Location = new Point(3, 3);
            dataGridViewUsers.Name = "dataGridViewUsers";
            dataGridViewUsers.RowTemplate.Height = 25;
            dataGridViewUsers.Size = new Size(930, 397);
            dataGridViewUsers.TabIndex = 0;
            // 
            // Мероприятия
            // 
            Мероприятия.Controls.Add(dataGridViewEvents);
            Мероприятия.Location = new Point(4, 24);
            Мероприятия.Name = "Мероприятия";
            Мероприятия.Padding = new Padding(3);
            Мероприятия.Size = new Size(936, 403);
            Мероприятия.TabIndex = 1;
            Мероприятия.Text = "Мероприятия";
            Мероприятия.UseVisualStyleBackColor = true;
            // 
            // dataGridViewEvents
            // 
            dataGridViewEvents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewEvents.Dock = DockStyle.Fill;
            dataGridViewEvents.Location = new Point(3, 3);
            dataGridViewEvents.Name = "dataGridViewEvents";
            dataGridViewEvents.RowTemplate.Height = 25;
            dataGridViewEvents.Size = new Size(930, 397);
            dataGridViewEvents.TabIndex = 0;
            // 
            // Посещения
            // 
            Посещения.Controls.Add(dataGridViewVisits);
            Посещения.Location = new Point(4, 24);
            Посещения.Name = "Посещения";
            Посещения.Size = new Size(936, 403);
            Посещения.TabIndex = 2;
            Посещения.Text = "Посещения";
            Посещения.UseVisualStyleBackColor = true;
            // 
            // dataGridViewVisits
            // 
            dataGridViewVisits.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewVisits.Dock = DockStyle.Fill;
            dataGridViewVisits.Location = new Point(0, 0);
            dataGridViewVisits.Name = "dataGridViewVisits";
            dataGridViewVisits.RowTemplate.Height = 25;
            dataGridViewVisits.Size = new Size(936, 403);
            dataGridViewVisits.TabIndex = 0;
            // 
            // Темы_выступлений
            // 
            Темы_выступлений.Controls.Add(dataGridViewThemes);
            Темы_выступлений.Location = new Point(4, 24);
            Темы_выступлений.Name = "Темы_выступлений";
            Темы_выступлений.Size = new Size(936, 403);
            Темы_выступлений.TabIndex = 3;
            Темы_выступлений.Text = "Темы_выступлений";
            Темы_выступлений.UseVisualStyleBackColor = true;
            // 
            // dataGridViewThemes
            // 
            dataGridViewThemes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewThemes.Dock = DockStyle.Fill;
            dataGridViewThemes.Location = new Point(0, 0);
            dataGridViewThemes.Name = "dataGridViewThemes";
            dataGridViewThemes.RowTemplate.Height = 25;
            dataGridViewThemes.Size = new Size(936, 403);
            dataGridViewThemes.TabIndex = 0;
            // 
            // Участники
            // 
            Участники.Controls.Add(dataGridViewParticipants);
            Участники.Location = new Point(4, 24);
            Участники.Name = "Участники";
            Участники.Size = new Size(936, 403);
            Участники.TabIndex = 4;
            Участники.Text = "Участники";
            Участники.UseVisualStyleBackColor = true;
            // 
            // dataGridViewParticipants
            // 
            dataGridViewParticipants.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewParticipants.Dock = DockStyle.Fill;
            dataGridViewParticipants.Location = new Point(0, 0);
            dataGridViewParticipants.Name = "dataGridViewParticipants";
            dataGridViewParticipants.RowTemplate.Height = 25;
            dataGridViewParticipants.Size = new Size(936, 403);
            dataGridViewParticipants.TabIndex = 0;
            // 
            // Клиенты
            // 
            Клиенты.Controls.Add(dataGridViewCustomers);
            Клиенты.Location = new Point(4, 24);
            Клиенты.Name = "Клиенты";
            Клиенты.Size = new Size(936, 403);
            Клиенты.TabIndex = 5;
            Клиенты.Text = "Клиенты";
            Клиенты.UseVisualStyleBackColor = true;
            // 
            // dataGridViewCustomers
            // 
            dataGridViewCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCustomers.Dock = DockStyle.Fill;
            dataGridViewCustomers.Location = new Point(0, 0);
            dataGridViewCustomers.Name = "dataGridViewCustomers";
            dataGridViewCustomers.RowTemplate.Height = 25;
            dataGridViewCustomers.Size = new Size(936, 403);
            dataGridViewCustomers.TabIndex = 0;
            // 
            // Договоры
            // 
            Договоры.Controls.Add(dataGridViewContracts);
            Договоры.Location = new Point(4, 24);
            Договоры.Name = "Договоры";
            Договоры.Size = new Size(936, 403);
            Договоры.TabIndex = 6;
            Договоры.Text = "Договоры";
            Договоры.UseVisualStyleBackColor = true;
            // 
            // dataGridViewContracts
            // 
            dataGridViewContracts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewContracts.Dock = DockStyle.Fill;
            dataGridViewContracts.Location = new Point(0, 0);
            dataGridViewContracts.Name = "dataGridViewContracts";
            dataGridViewContracts.RowTemplate.Height = 25;
            dataGridViewContracts.Size = new Size(936, 403);
            dataGridViewContracts.TabIndex = 0;
            dataGridViewContracts.CellContentClick += dataGridViewContracts_CellContentClick;
            // 
            // button1
            // 
            button1.Location = new Point(16, 511);
            button1.Name = "button1";
            button1.Size = new Size(231, 23);
            button1.TabIndex = 2;
            button1.Text = "Управление договорами";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(16, 549);
            button2.Name = "button2";
            button2.Size = new Size(231, 23);
            button2.TabIndex = 3;
            button2.Text = "Управление клиенами";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(253, 511);
            button3.Name = "button3";
            button3.Size = new Size(231, 23);
            button3.TabIndex = 4;
            button3.Text = "Управление мероприятиями";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(253, 549);
            button4.Name = "button4";
            button4.Size = new Size(231, 23);
            button4.TabIndex = 5;
            button4.Text = "Управление участниками";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(490, 511);
            button5.Name = "button5";
            button5.Size = new Size(231, 23);
            button5.TabIndex = 6;
            button5.Text = "Управление пользователями";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(490, 549);
            button6.Name = "button6";
            button6.Size = new Size(231, 23);
            button6.TabIndex = 7;
            button6.Text = "Управление посещениями";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(723, 511);
            button7.Name = "button7";
            button7.Size = new Size(225, 23);
            button7.TabIndex = 8;
            button7.Text = "Управление темами выступлений";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(Формы);
            tabControl2.Controls.Add(Отчеты);
            tabControl2.Location = new Point(0, 39);
            tabControl2.Name = "tabControl2";
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new Size(952, 455);
            tabControl2.TabIndex = 9;
            // 
            // Формы
            // 
            Формы.Controls.Add(tabControl1);
            Формы.Location = new Point(4, 24);
            Формы.Name = "Формы";
            Формы.Padding = new Padding(3);
            Формы.Size = new Size(944, 427);
            Формы.TabIndex = 0;
            Формы.Text = "Формы";
            Формы.UseVisualStyleBackColor = true;
            // 
            // Отчеты
            // 
            Отчеты.Controls.Add(tabControl3);
            Отчеты.Location = new Point(4, 24);
            Отчеты.Name = "Отчеты";
            Отчеты.Padding = new Padding(3);
            Отчеты.Size = new Size(944, 427);
            Отчеты.TabIndex = 1;
            Отчеты.Text = "Отчеты";
            Отчеты.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            tabControl3.Controls.Add(tabPage1);
            tabControl3.Controls.Add(tabPage2);
            tabControl3.Controls.Add(tabPage3);
            tabControl3.Location = new Point(-4, 0);
            tabControl3.Name = "tabControl3";
            tabControl3.SelectedIndex = 0;
            tabControl3.Size = new Size(948, 431);
            tabControl3.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(dataGridView1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(940, 403);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Договоры суммой больше 70к";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(3, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(934, 397);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(dataGridView2);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(940, 403);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Темы по индефикатору мероприятия номер 1";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Dock = DockStyle.Fill;
            dataGridView2.Location = new Point(3, 3);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowTemplate.Height = 25;
            dataGridView2.Size = new Size(934, 397);
            dataGridView2.TabIndex = 0;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(dataGridView3);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(940, 403);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "ID Администраторов";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Dock = DockStyle.Fill;
            dataGridView3.Location = new Point(0, 0);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowTemplate.Height = 25;
            dataGridView3.Size = new Size(940, 403);
            dataGridView3.TabIndex = 0;
            // 
            // button8
            // 
            button8.Location = new Point(839, 578);
            button8.Name = "button8";
            button8.Size = new Size(113, 23);
            button8.TabIndex = 10;
            button8.Text = "О программе";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(839, 549);
            button9.Name = "button9";
            button9.Size = new Size(113, 23);
            button9.TabIndex = 11;
            button9.Text = "Выход";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(962, 613);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(tabControl2);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "AdminForm";
            Text = "Repost";
            tabControl1.ResumeLayout(false);
            Пользователи.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewUsers).EndInit();
            Мероприятия.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewEvents).EndInit();
            Посещения.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewVisits).EndInit();
            Темы_выступлений.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewThemes).EndInit();
            Участники.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewParticipants).EndInit();
            Клиенты.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).EndInit();
            Договоры.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewContracts).EndInit();
            tabControl2.ResumeLayout(false);
            Формы.ResumeLayout(false);
            Отчеты.ResumeLayout(false);
            tabControl3.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TabControl tabControl1;
        private TabPage Пользователи;
        private TabPage Мероприятия;
        private TabPage Посещения;
        private TabPage Темы_выступлений;
        private TabPage Участники;
        private TabPage Клиенты;
        private TabPage Договоры;
        private DataGridView dataGridViewUsers;
        private DataGridView dataGridViewEvents;
        private DataGridView dataGridViewVisits;
        private DataGridView dataGridViewThemes;
        private DataGridView dataGridViewParticipants;
        private DataGridView dataGridViewCustomers;
        private DataGridView dataGridViewContracts;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private TabControl tabControl2;
        private TabPage Формы;
        private TabPage Отчеты;
        private TabControl tabControl3;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private DataGridView dataGridView1;
        private TabPage tabPage3;
        private DataGridView dataGridView2;
        private DataGridView dataGridView3;
        private Button button8;
        private Button button9;
    }
}
